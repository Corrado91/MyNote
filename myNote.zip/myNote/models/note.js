const mongoose = require('mongoose');

const noteSchema = mongoose.Schema({
    titolo:{
        type: String,
        require: true
    },
    contenuto:{
        type: String,
        require: true
    },
    utente:{
        type: String,
        require: true
    },
    data:{
        type: Date,
        default: Date.now
    }
})

mongoose.model('note', noteSchema);