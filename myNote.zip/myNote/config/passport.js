const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

//SCHEMA E MODELLO PER UTENTI
require('../models/utenti');
const Utenti = mongoose.model('Utenti');

//MODULO ESPORTATO E VERIFICA DELLE CREDENZIALI
module.exports = function(passport){
    passport.use(new LocalStrategy({usernameField:'email'}, (email, password, done)=>{
        //console.log(password);
        Utenti.findOne({ //VERIFICA EMAIL 
            email:email
        }).then(utente =>{
            if(!utente){
                return done(null, false, {message: 'Utente non trovato!'})
            }
            //VERIFICA PASSWORD
            bcrypt.compare(password, utente.password, (err, comparato) =>{
                if(err){
                 throw err;
                }
                if(comparato){
                    return done(null, utente);
                }else{
                    return done(null, false, {message: 'password non corretta!'});
                }
            });
        })
    }));

    //SESSIONE UTENTE
    passport.serializeUser(function(utente, done) {
        done(null, utente.id);
      });      
      passport.deserializeUser(function(id, done) {
        Utenti.findById(id, function(err, utente) {
          done(err, utente);
        });
      });
}