//SECTION REQUIRE
const express = require('express');
//const handlebars = require('handlebars');
const bodyParser = require('body-parser');
const exphbs  = require('express-handlebars');
const flash = require('connect-flash');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const methodOverride = require('method-override');
const passport = require('passport');
const mongoose = require('mongoose');

const app = express();

//Accesso area Utente
const {accessoSicuro} = require('../myNote/helpers/accesso_privato');

//INTEGRAZIONE FILE CONFIG PASSPORT
require('../myNote/config/passport')(passport);

//SCHEMA E MODELLO PER NOTE
require('./models/note');
const Note = mongoose.model('note');

//SCHEMA E MODELLO PER UTENTI
require('./models/utenti');
const Utenti = mongoose.model('Utenti');

//CARTELLE PER LE GESTIONE STATICHE
app.use('/css', express.static(__dirname + '/assets/css'));
app.use(express.static(__dirname + '/assets/img'));

//MIDDLEWARE HANDLEBARS 
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');

//CONNESSIONE A MONGOOSE
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/note', { useNewUrlParser: true })
.then(() =>{
    console.log('Database connesso')
})
.catch(err =>(err));

//MIDDLEWARE DI METHOD-OVERRIDE
app.use(methodOverride('_method'));

//MIDDLEWARE PER SESSION
app.use(session({
    secret: 'keyboard cat',
    resave: true,
    saveUninitialized: true
}))

//MIDDLEWARE PASSPORT
app.use(passport.initialize());
app.use(passport.session());

//MIDDLEWARE PER MESSAGGI FLASH
app.use(flash());

//VARIABILI GLOBALI PER MESSAGGI FLASH
app.use((req, res, next) =>{
    res.locals.msg_successo = req.flash("msg_successo");
    res.locals.msg_errore = req.flash("msg_errore");
    res.locals.error = req.flash('error');
    res.locals.user = req.user;
    next();
})

//Routing della pagina index
app.get('/', (req, res)=>{
    const titolo = "Benvenuto su MyNote";
    res.render('index', {titolo: titolo});
})

//Routing della pagina info
app.get('/info', (req, res)=>{
    const titolo = "Benvenuto su MyNote";
    res.render('INFO', {titolo: titolo});
})

//ROUTING DELLA PAGINA AGGIUNGI_NOTA
app.get('/aggiungi_nota', accessoSicuro, (req, res)=>{
    res.render('aggiungi_nota');
})

//ROUTING DELLA PAGINA MODIFICA_NOTA
app.get('/modifica_nota/:id', accessoSicuro, (req, res)=>{
    Note.findOne({
        _id: req.params.id
    })
    .then(nota =>{
        if(nota.utente != req.user.id ){
            req.flash('msg_errore', 'Area riservata'),
            res.redirect('/lista_note')
        }else{
            res.render('modifica_nota', {
                nota: nota
            });
        }
    });
});

//ROUTING DELLA PAGINA LISTA_NOTE
app.get('/lista_note', accessoSicuro, (req, res)=>{
    Note.find({utente: req.user.id})
    .sort({date: 'desc'})
    .then(note =>{
        res.render('lista_note', {
            note: note
        })
    })
    //res.render('');
})

//ROUTING DELLA PAGINA LOGIN
app.get('/login', (req, res)=>{
    res.render('login');
})

//ROUTING DELLA PAGINA REGISTRAZIONE
app.get('/registrazione', (req, res) =>{
    res.render('registrazione');
})

//MIDDLEWARE DI BODY-PARSER
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

//GESTIONE DEL FORM AGGIUNGI
app.post('/aggiungi_nota', accessoSicuro, (req, res) =>{
    //res.send("OK, funziona");
    let errori = [];
    if(!req.body.titolo){
        errori.push({text:"Devi riempire il campo titolo!"});
    }
    if(!req.body.testo){
        errori.push({text:"Devi riempire il campo testo!"});
    }
    if(errori.length > 0){
        res.render("aggiungi_nota", {
            errori: errori,
            titolo: req.body.titolo,
            testo: req.body.testo
        });
    }else{
        //res.send("OK, sta funzionando!");
        const nuovaNota = {
            titolo: req.body.titolo,
            contenuto: req.body.testo,
            utente: req.user.id
        }
        new Note(nuovaNota)
        .save()
        .then(nota =>{
            req.flash('msg_successo', 'Nota Aggiunta Correttamente!')
            res.redirect('/lista_note');
        })
    }
})

//GESTIONE DEL FORM: AGGIORNA
app.post('/lista_note/:id', accessoSicuro, (req, res) =>{
    Note.findOne({
        _id:req.params.id
    })
    .then(nota =>{
        nota.titolo = req.body.titolo;
        nota.contenuto = req.body.testo;
        nota.save()
        .then(nota =>{
            req.flash('msg_successo', 'Nota Modificata Correttamente!')
            res.redirect('/lista_note');
        });
    });
});

//GESTIONE PER ELIMINAZIONE DELLE NOTE
app.delete('/lista_note/:id', accessoSicuro, (req, res) =>{
    Note.remove({
        _id: req.params.id
    })
    .then(nota =>{
        req.flash('msg_successo', 'Nota Cancellata Correttamente!')
        res.redirect('/lista_note');
    });
});

//GESTIONE FORM REGISTRAZIONE
app.post('/registrazione', (req, res) =>{
    let errori = [ ];
    if(req.body.password != req.body.conferma_psw){
        errori.push({text: 'password non corrispondenti'});
    }
    if(req.body.password.length < 6){
        errori.push({text: 'la password deve avere almeno 6 caratteri'})
    }
    if(errori.length > 0){
        res.render('registrazione', {
            errori: errori,
            nome: req.body.nome,
            cognome: req.body.cognome,
            email: req.body.email,
            password: req.body.password,
            conferma_psw: req.body.conferma_psw
        });
    }else{
        Utenti.findOne({email: req.body.email})
        .then(utente =>{
            if(utente){
                req.flash('msg_errore', 'Questa email è già registrata');
                res.redirect('/registrazione');
            }else{
                const nuovoUtente = new Utenti({
                    nome:req.body.nome,
                    cognome:req.body.cognome,
                    email:req.body.email,
                    password:req.body.password
                });
                bcrypt.genSalt(10, (err, salt) =>{
                    bcrypt.hash(nuovoUtente.password, salt, (err, hash) =>{
                        if(err) throw err;
                        nuovoUtente.password = hash;
                        nuovoUtente.save()
                        .then(Utenti =>{
                            req.flash('msg_successo', 'Ti sei Registrato');
                            res.redirect('login');
                        })
                        .catch(err =>{
                            console.log(err);
                            return;
                        });
                    });
                });
            }
        });
    }
});

//GESTIONE FORM LOGIN CON PASSPORT
app.post('/login', (req, res, next) =>{
    passport.authenticate('local', {
        successRedirect: '/lista_note',
        failureRedirect: '/login',
        failureFlash: true
    })(req, res, next);

});

//GESTIONE LOGAUT
app.get('/logout', (req, res) =>{
    req.logout();
    req.flash('msg_successo', 'Ti sei disconesso, Ciao alla prossima!');
    res.redirect('/');
}) 



//collegamento alla porta
const port = 3000;
app.listen(port, ()=>{
    console.log('server attivo nella porta: 3000');
})
//USO DI BASE DELLE MIDDLEWARE 
// app.use((req, res, next)=>{
    //     req.saluto = "Io sono la prima app in node.js";
//     next();
// })
// app.get('/', (req, res) =>{
//     res.send(req.saluto);
// }); <------ middleware